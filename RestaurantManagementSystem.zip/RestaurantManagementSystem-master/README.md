# RestaurantManagementSystem

## Description:
This is a simple restaruant management system based on **desktop application**.I used to develop it with **C#** and **.Net Framework**. I managed database part on **MySql** and **Xampp** local host server.

## Set Up Guide: 
* Firstly needed to install "Xampp" local host server
* Start "Apache" then Start "MySql"
* Open your browser and visit : http://localhost/phpmyadmin/
* Then Click "Import" and upload the file "127_0_0_1.sql" from the "Database" Folder

Now **Database is ready.** 

#### Simply open the "RestaurantManagement.exe" file to start the Application.

## Development Guide:
* install "Xampp" local host server
* Install "Visual Studio" with "C#.Net" Framework
* Install "mysql connector" from "Connector" folder

Now **Development Enviornment Ready.**

Adding **Database..**
* Firstly needed to open "Xampp" local host server
* Start "Apache" then Start "MySql"
* Open your browser and visit : http://localhost/phpmyadmin/
* Then Click "Import" and upload the file "127_0_0_1.sql" from the "Database" Folder

Now **Database is also ready.** 

After This , go to "RestaurantManagement" Folder and open "RestaurantManagement.sln" File
to open the project and ready to development.

To more query about this Application, you can go to the **"System Analysis and Design"** folder.
or Contact : **anam.mubin1999@gmail.com** , Phone: 01517006330
